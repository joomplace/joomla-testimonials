<?php
/**
* Testimonials Component for Joomla 3
* @package Testimonials
* @author JoomPlace Team
* @copyright Copyright (C) JoomPlace, www.joomplace.com
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/
defined('_JEXEC') or die('Restricted Access');
?>
<!--
<tr>
        <td colspan="3">
		<?php //echo $this->pagination?$this->pagination->getListFooter():''; 
		?></td>
</tr>
-->